const COLORS = {
    primary : "#yetee"
}

export default COLORS;