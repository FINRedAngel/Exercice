import React from 'react'

const GameOverScreen = () => {
  return (
    <div>GameOverScreen</div>
  )
}

export default GameOverScreen