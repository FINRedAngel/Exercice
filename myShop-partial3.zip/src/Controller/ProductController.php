<?php

namespace App\Controller;

use App\Entity\Product;
use App\Form\ProductType;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{
    /**
     * @Route("/product", name="app_product")
     */
    public function index(): Response
    {
        return $this->render('product/index.html.twig');
    }

    /**
     * @Route("/product/add", name="product_add")
     */
    public function add(ManagerRegistry $doctrine, Request $request)
    {
        #Etape 1 : On créé un objet "product" vide
        $product = new Product();

        #Etape 2 : on alimente l'objet avec des valeurs
        $product->setCreatedAt(new \DateTime());

        #Etape 3 : Méthode 1 : créer le formulaire
        // $formProduct = $this->createFormBuilder($product)
        //         ->add('title', TextType::class)
        //         ->add('price', NumberType::class)
        //         ->add('description', TextareaType::class)
        //         // ->add('save', SubmitType::class)
        //         ->getForm();

        #Etape 3 : Méthode 2 : créer le formulaire
        $formProduct = $this->createForm(ProductType::class, $product);

        $formProduct->handleRequest($request);
        #On vérifie si le bouton submit a été cliqué et si c'est valide
        if($formProduct->isSubmitted() && $formProduct->isValid())
        {
            #Etape 4bis : Appeler l'entityManager de doctrine pour l'enregistrement
            $entityManager = $doctrine->getManager();
            $entityManager->persist($product);
            $entityManager->flush();

            #Créer un message flash
            $this->addFlash('add_success', "Le produit a bien été ajouté !");

            return $this->redirectToRoute('app_home');
        }

        #Etape 4 : Rediriger vers une page ou afficher une page
        return $this->render("product/form-add.html.twig", [
            'formProduct' => $formProduct->createView()
        ]);
    }

    /**
     * @Route("/product/edit/{id}", name="product_edit")
     */
    public function edit($id, ManagerRegistry $doctrine, Request $request)
    {
        #Etape 1 : On récupère l'objet qui a l'id : $id
        $product = $doctrine->getRepository(Product::class)->find($id);

        #Etape 2 : On modifie les valeurs souhaitées
        $product->setUpdatedAt(new \DateTime());

        #Etape 3 : Méthode 2 : créer le formulaire
        $formProduct = $this->createForm(ProductType::class, $product);

        $formProduct->handleRequest($request);
        #On vérifie si le bouton submit a été cliqué et si c'est valide
        if($formProduct->isSubmitted() && $formProduct->isValid())
        {
            #Etape 3 : On appel l'entity manager de doctrine pour enregistrer
            $entityManager = $doctrine->getManager();
            $entityManager->flush();

            #Créer un message flash
            $this->addFlash('edit_success', "Le produit a bien été modifié !");
            
            return $this->redirectToRoute('app_home');
        }

        #Etape 4 : Rediriger vers une page ou afficher une page
        return $this->render("product/form-edit.html.twig", [
            'formProduct' => $formProduct->createView()
        ]);        
    }

    /**
     * @Route("/product/delete/{id}", name="product_delete")
     */
    public function delete($id, ManagerRegistry $doctrine)
    {
        #Etape 1 : Récuperer l'objet qui a l'id : $id
        $product = $doctrine->getRepository(Product::class)->find($id);

        #Etape 2 : On appele l'entity manager de doctrine pour supprimer
        $em = $doctrine->getManager();
        $em->remove($product);
        $em->flush();

        #Créer un message flash
        $this->addFlash('delete_success', "Le produit a bien été supprimé !");

        #Etape 3 : Rediriger vers une page ou afficher une page
        return $this->redirectToRoute('app_home');       
    }

    /**
     * @Route("/product/show/{id}", name="show_product")
     */
    public function show($id, ManagerRegistry $doctrine)
    {
        $product = $doctrine->getRepository(Product::class)->find($id);

        return $this->render("product/show.html.twig", [
            'product' => $product
        ]);
    }

}
