<?php

namespace App\Controller;

use App\Entity\Product;
use App\Repository\ProductRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class HomeController extends AbstractController
{
    /**
     * @Route("/", name="app_home")
     */
    public function index(ManagerRegistry $doctrine): Response
    {
        #On récupère tous les produits
        $products = $doctrine->getRepository(Product::class)->findAll();

        return $this->render('home/index.html.twig', [
            'products' => $products
        ]);
    }

    /**
     * @Route("/home", name="orm_home")
     */
    public function home(ManagerRegistry $doctrine, ProductRepository $repository)
    {
        #Utiliser findAll() pour afficher toutes les données
        $productsAll = $doctrine->getRepository(Product::class)->findAll();
        //$findAll = $repository->findAll();

        #Utiliser find() pour afficher 1 donnée par son Id
        $productFindId = $doctrine->getRepository(Product::class)->find(1);

        #Utiliser findOneBy() pour afficher le produit qui coute 600€
        $productFindOneBy = $doctrine->getRepository(Product::class)->findOneBy(["price" => 600]);

        #Utiliser findBy() pour afficher tousles produits qui countent 600€
        $productFindBy = $doctrine->getRepository(Product::class)->findBy(["price" => 600]);

        #requete personnalisée :pour récuperer tous les produits de prix supérieur a 600€
        $productGreater = $doctrine->getRepository(Product::class)->findPriceGreaterThan(600);

        return $this->render("home/orm.html.twig", [
            'productsAll' => $productsAll,
            'productFindId' => $productFindId,
            'productFindOneBy' => $productFindOneBy,
            'productFindBy' => $productFindBy,
            'productGreater' => $productGreater
        ]);
    }
}
